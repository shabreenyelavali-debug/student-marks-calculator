from calculator import total
assert total([1,2,3])==6
